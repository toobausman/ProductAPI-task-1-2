import { useState } from "react";
import { Link } from "react-router-dom";
import AuthLayout from "./AuthLayout.jsx";
import WorkImg from "../assets/work.jpg";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    // UI only for now
    alert(`Login ready:\n${JSON.stringify({ username, password, remember }, null, 2)}`);
  };

  return (
    <AuthLayout
      title="Welcome back"
      subtitle="Enter your credentials to continue."
      artSrc= {WorkImg}
    >
      <form onSubmit={submit}>
        <label className="label" htmlFor="lu">Username</label>
        <div className="field">
          <input
            id="lu"
            className="input"
            placeholder="e.g. tooba"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="username"
          />
        </div>

        <label className="label" htmlFor="lp">Password</label>
        <div className="field">
          <input
            id="lp"
            type="password"
            className="input"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
          />
        </div>

        <div className="row">
          <label style={{ display: "flex", gap: 8, alignItems: "center", color: "#cbd5e1", fontSize: 13 }}>
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
            />
            Remember me
          </label>
          <a className="link" href="#">Forgot password?</a>
        </div>

        <button className="btn">SIGN IN</button>

        <div className="panel-foot">
          Not registered yet?{" "}
          <Link className="link" to="/register">Create an Account</Link>
        </div>
      </form>
    </AuthLayout>
  );
}
