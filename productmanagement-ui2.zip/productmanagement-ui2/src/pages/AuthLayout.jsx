export default function AuthLayout({ title, subtitle, children, artSrc }) {
  return (
    <div className="auth-page">
      <div className="auth-card">
        {/* left illustration (replace URL with your own if you like) */}
        <div className="auth-art">
          <img
            src={artSrc ?? "https://illustrations.popsy.co/gray/developer-activity.svg"}
            alt="Illustration"
          />
        </div>

        {/* right panel */}
        <div className="auth-form">
          <h1>{title}</h1>
          {subtitle && <p className="lead">{subtitle}</p>}
          {children}
        </div>
      </div>
    </div>
  );
}
