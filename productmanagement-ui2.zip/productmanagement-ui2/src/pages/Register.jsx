import { useState } from "react";
import { Link } from "react-router-dom";
import AuthLayout from "./AuthLayout.jsx";
import WorkImg from "../assets/work.jpg";
export default function Register() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm,  setConfirm ] = useState("");

  const submit = (e) => {
    e.preventDefault();
    if (password !== confirm) {
      alert("Passwords do not match.");
      return;
    }
    // UI only for now
    alert(`Signup ready:\n${JSON.stringify({ username, password }, null, 2)}`);
  };

  return (
    <AuthLayout
      title="Create account"
      subtitle="It’s quick and easy."
      artSrc={WorkImg}
    >
      <form onSubmit={submit}>
        <label className="label" htmlFor="ru">Username</label>
        <div className="field">
          <input
            id="ru"
            className="input"
            placeholder="e.g. tooba"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="username"
          />
        </div>

        <label className="label" htmlFor="rp">Password</label>
        <div className="field">
          <input
            id="rp"
            type="password"
            className="input"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
          />
        </div>

        <label className="label" htmlFor="rc">Confirm password</label>
        <div className="field">
          <input
            id="rc"
            type="password"
            className="input"
            placeholder="••••••••"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            autoComplete="new-password"
          />
        </div>

        <button className="btn">CREATE ACCOUNT</button>

        <div className="panel-foot">
          Already have an account?{" "}
          <Link className="link" to="/login">Sign in</Link>
        </div>
      </form>
    </AuthLayout>
  );
}
